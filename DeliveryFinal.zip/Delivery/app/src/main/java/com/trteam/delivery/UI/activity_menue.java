package com.trteam.delivery.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.trteam.delivery.R;

public class activity_menue extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menue);
        Button Add_Button = findViewById(R.id.Add_Parcel);

         //callbacks to pass to the wanted activity when button clicked

        Add_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(activity_menue.this, AddParcelActivity.class);
                startActivity(intent);
            }
        });
        Button History_Button= findViewById(R.id.History_Parcel);
        History_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(activity_menue.this, history_parcels_activity.class);
                startActivity(intent);
            }
        });
    }
}