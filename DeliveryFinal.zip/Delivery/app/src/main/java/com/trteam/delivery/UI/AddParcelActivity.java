package com.trteam.delivery.UI;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.lang.String;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.android.material.snackbar.Snackbar;
import com.trteam.delivery.Entitiy.Parcel;
import com.trteam.delivery.R;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.widget.Toast;

import java.util.Calendar;

public class AddParcelActivity extends AppCompatActivity  {
//region Declarations
    private Button history;
    CheckBox fragile;
    private Spinner spinner;
    private Spinner spinnerweight;
    private Spinner spinnerstatus;
    EditText phoneNumber;
    EditText nameofdelivery;

    EditText shippingDate;
    EditText acceptionDate;
    EditText email;
    EditText recipientName;
    EditText eText;
    EditText eAccept;
    DatePickerDialog aceptPicker;
    DatePickerDialog picker;

    private Button location_button;
    private TextView location_textView;
    LocationManager locationManager;
    LocationListener locationListener;
    //endregion

    static boolean flag=true;//if not important input correct-don't save new parcel
    //declaring firebase functions to access the db
    final static FirebaseDatabase database = FirebaseDatabase.getInstance();
    final static DatabaseReference myRef = database.getReference("parcels");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parcel);

        //region Location

        location_button = (Button) findViewById(R.id.btn_Locatiom);
        location_textView = (TextView) findViewById(R.id.textView_Location);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {//when location updates
                location_textView.setText(" " + location.getLongitude() + "\n " + location.getLatitude());

            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {            }

            @Override
            public void onProviderDisabled(String provider) {//check if  gps is  turned off
                Intent intentCor = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intentCor);
            }
        };

        configurLocationButton();//calls function for location
       //endregion


        //region Spinners
        //Adapter settings for the spinner
        spinner=findViewById(R.id.spinnerparcel);
        //Creates a new ArrayAdapter from external resources.
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.parcel_type,android.R.layout.simple_spinner_item);
        //Sets the layout resource to create the drop down views
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        //Sets a listener to be invoked when an item in the list is selected.
        spinner.setOnItemSelectedListener(new ParcelTypeclass());

        spinnerweight=findViewById(R.id.spinnerweight);
        ArrayAdapter<CharSequence> adapterweight=ArrayAdapter.createFromResource(this,R.array.parcel_weight,android.R.layout.simple_spinner_item);
        adapterweight.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerweight.setAdapter(adapterweight);
        spinnerweight.setOnItemSelectedListener(new ParcelWeightclass ());

        spinnerstatus=findViewById(R.id.spinnerstatus);
        ArrayAdapter<CharSequence> adapterstatus=ArrayAdapter.createFromResource(this,R.array.Parcel_Status,android.R.layout.simple_spinner_item);
        adapterstatus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerstatus.setAdapter(adapterstatus);
        spinnerstatus.setOnItemSelectedListener(new ParcelStatusclass ());
       //endregion


        //region Recognition
        nameofdelivery = (EditText) findViewById(R.id.nameofdeliver);
        fragile=(CheckBox) findViewById(R.id.fragile) ;
        email = (EditText) findViewById(R.id.editTextEmail) ;
        acceptionDate =  findViewById(R.id.editacceptDate);
        shippingDate =  findViewById(R.id.editShippingDate);
        recipientName = findViewById(R.id.Ownername);
        phoneNumber=(EditText)findViewById(R.id.editTextNumber);
        eAccept=(EditText)findViewById(R.id.editaccepParceltDate);
        eAccept.setInputType(InputType.TYPE_NULL);
        eText=(EditText)findViewById(R.id.editText1);
        eText.setInputType(InputType.TYPE_NULL);
        //endregion


        //region Calendar settings
        eText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final Calendar clnd=Calendar.getInstance();
                int day=clnd.get(Calendar.DAY_OF_MONTH);
                int month=clnd.get(Calendar.MONTH);
                int year=clnd.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(AddParcelActivity.this, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                eText.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                picker.show();
                shippingDate.setText("Selected Date: "+ eText.getText());
            }
        });

        eAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar clnd=Calendar.getInstance();
                int day=clnd.get(Calendar.DAY_OF_MONTH);
                int month=clnd.get(Calendar.MONTH);
                int year=clnd.get(Calendar.YEAR);
                // date picker dialog
                aceptPicker = new DatePickerDialog(AddParcelActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        eAccept.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }
                }, year, month, day);
                aceptPicker.show();
            }
        });
        //endregion


        //region Add Button
        Button addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {

                Parcel parcel = new Parcel();


                //region validations + parcel updates
                final TextView textView = (TextView)findViewById(R.id.text);

                String Email = email.getText().toString().trim();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";


                if (Email.matches(emailPattern))
                {
                    parcel.setEmail(email.getText().toString());
                    flag=true;
                }
                else
                {Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_LONG).show();}
                flag=false;

                if(TextUtils.isEmpty(nameofdelivery.getText()))
                {nameofdelivery.setError("Enter value");
                nameofdelivery.requestFocus();
                flag=false;}
                else
                {parcel.setNameDelivery(nameofdelivery.getText().toString());
                flag=true;}
                if (!TextUtils.isDigitsOnly(phoneNumber.getText()))
                {phoneNumber.setError("Enter digit only");
                flag=false;}
                else if (TextUtils.isEmpty(phoneNumber.getText())||phoneNumber.length()<9)
                {phoneNumber.setError("Pleas enter valid PhoneNumber");
                flag=false;}
                else
                {parcel.setPhoneNumber(phoneNumber.getText().toString());
                flag=true;}
               //endregion


                //region Parcel Update
                parcel.setLocation(location_textView.getText().toString());
                parcel.setFragile(fragile.isChecked());
                parcel.setParcelType(spinner.getSelectedItem().toString());
                parcel.setParcelStatus(spinnerstatus.getSelectedItem().toString());
                parcel.setParcelWeight(spinnerweight.getSelectedItem().toString());
                parcel.setShippingDate(eText.getText().toString());
                parcel.setShippingDate(eAccept.getText().toString());
                parcel.setAcceptDate(acceptionDate.getText().toString());
                parcel.setShippingDate(shippingDate.getText().toString());
                parcel.setRecipient(recipientName.getText().toString());
                //endregion

                //region FireBase update
              if (flag==true) {
                  myRef.push().setValue(parcel).addOnSuccessListener(new OnSuccessListener<Void>() {
                      @Override
                      public void onSuccess(Void aVoid) {

                          Snackbar.make(v, "Save", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                      }
                  });
              }
              //endregion
            }
        });

        //endregion


        //region History Button
        history=(Button)findViewById(R.id.history);
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity_history_parcels();
            }
        });
        //endregion
    }

    //region Localisation settings
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissizon, @NonNull int[] grantResuls) {
        switch (requestCode) {
            case 10:
                if (grantResuls.length > 0 && grantResuls[0] == PackageManager.PERMISSION_GRANTED)
                    configurLocationButton();
                return;
        }
    }

    private void configurLocationButton() {
        location_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.INTERNET
                    }, 10);
                    return;
                }
                locationManager.requestLocationUpdates("gps", 0, 0, locationListener);
            }
        });
    }
    //endregion


   //region Spinners adapter listeners

   public class ParcelTypeclass implements AdapterView.OnItemSelectedListener {
        //help us with diferent cases..
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {    }
   }

    public class ParcelWeightclass implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String text = parent.getItemAtPosition(position).toString();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {        }
    }


    public class ParcelStatusclass implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String text = parent.getItemAtPosition(position).toString();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {        }
    }


    public void openactivity_history_parcels(){
        Intent intent = new Intent(this,history_parcels_activity.class);
        startActivity(intent);
    }
    //endregion
}