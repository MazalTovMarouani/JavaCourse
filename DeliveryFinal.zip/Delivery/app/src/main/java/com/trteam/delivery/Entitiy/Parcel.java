package com.trteam.delivery.Entitiy;

import android.location.Location;
import android.provider.ContactsContract;
import android.widget.CheckBox;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Parcel {
    //region Variables
    private boolean fragile;
    private Enumes.ParcelStatus parcelStatus;
    private Enumes.ParcelType parcelType;
    private Enumes.ParcelWeight parcelWeight;
    private String  recipient;
    private String shippingDate;
    private String acceptDate;
    private String location;
    private String nameDelivery;
    private String email;
    private String phoneNumber;
    //endregion

    //region Constructors
    public Parcel() {
    }

    public Parcel(boolean fragile, Enumes.ParcelStatus parcelStatus, Enumes.ParcelType parcelType, Enumes.ParcelWeight parcelWeight, String recipient, String shippingDate, String acceptDate, String location, String nameDelivery, String email, String phoneNumber) {
        this.fragile = fragile;
        this.parcelStatus = parcelStatus;
        this.parcelType = parcelType;
        this.parcelWeight = parcelWeight;
        this.recipient = recipient;
        this.shippingDate = shippingDate;
        this.acceptDate = acceptDate;
        this.location = location;
        this.nameDelivery = nameDelivery;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public Parcel(ParcelFromFirebase parceldb) {
        this.parcelStatus = parceldb.parcelStatus;
        this.parcelType = parceldb.parcelType;
        this.parcelWeight = parceldb.parcelWeight;
    }
    //endregion

    //region Getters
    public Enumes.ParcelType getParcelType() {
        return parcelType;
    }

    public Enumes.ParcelWeight getParcelWeight() {
        return parcelWeight;
    }

    public String getNameDelivery() {
        return nameDelivery;
    }

    public String getEmail() {
        return email;
    }

    public boolean isFragile() {
        return fragile;
    }

    public String  getRecipient() {
        return recipient;
    }

    public Enumes.ParcelStatus getParcelStatus() {
        return parcelStatus;
    }

    public String getShippingDate() {
        return shippingDate;
    }

    public String getAcceptDate() {
        return acceptDate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
    //endregion

    //region Setters

    public void setNameDelivery(String nameDelivery) {
        this.nameDelivery = nameDelivery;
    }

    public void setParcelStatus(String parcelStatus) {
        this.parcelStatus = Enumes.ParcelStatus.valueOf(parcelStatus);
    }

    public void setParcelWeight(String parcelWeight) {
        this.parcelWeight = Enumes.ParcelWeight.valueOf(parcelWeight);
    }

    public void setParcelType( String parcelType) {
        this.parcelType = Enumes.ParcelType.valueOf(parcelType);
    }

    public void setFragile(boolean fragile) {
        this.fragile = fragile;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setShippingDate(String shippingDate) {
        this.shippingDate = shippingDate;
    }

    public void setAcceptDate(String acceptDate) {
        this.acceptDate = acceptDate;
    }

    public void setRecipient(String recipient) {
        this.recipient=recipient;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setLocation(String toString) {
        this.location=toString;
    }

    //endregion
}