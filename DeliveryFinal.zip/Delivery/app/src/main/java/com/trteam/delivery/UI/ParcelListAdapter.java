package com.trteam.delivery.UI;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.trteam.delivery.Entitiy.Parcel;

import com.trteam.delivery.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ParcelListAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<ParcelListAdapter.ParcelViewHolder> {

    private Context baseContext;
    List<Parcel> parcels;

    public ParcelListAdapter(Context baseContext, List<Parcel> parcels) {
        this.baseContext = baseContext;
        this.parcels = parcels;
    }

    // Called when RecyclerView needs a new RecyclerView.ViewHolder of the given type
    // to represent an item.
    @NonNull
    @Override
    public ParcelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(baseContext).inflate(R.layout.parcel_cardview,
                parent, false);

        return new ParcelViewHolder(v);
    }


    // Called by RecyclerView to display the data at the specified position.
    @Override
    public void onBindViewHolder(@NonNull ParcelViewHolder holder, int position) {
        Parcel parcel = parcels.get(position);
        holder.textViewStatus.setText(parcel.getParcelStatus().name());
        holder.textViewType.setText(parcel.getParcelType().name());
        holder.textViewWeight.setText(parcel.getParcelWeight().name());
        holder.number.setText(parcel.getPhoneNumber());
        holder.textViewAdress.setText(parcel.getNameDelivery());
        holder.recipientName.setText(parcel.getRecipient());
        holder.textViewaccept.setText(parcel.getAcceptDate());
        holder.textVeiwShiping.setText(parcel.getShippingDate());
    }


    // Returns the total number of items in the data set held by the adapter.
    @Override
    public int getItemCount() {
        return parcels.size();
    }

    public class ParcelViewHolder extends RecyclerView.ViewHolder{
        TextView textViewStatus,textViewAdress, textViewType, recipientName,textViewWeight, number, fragil, textViewaccept, textVeiwShiping;

        public ParcelViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewStatus = itemView.findViewById(R.id.text_view_status);
            textViewWeight = itemView.findViewById(R.id.text_view_weight);
            //textViewAdress = itemView.findViewById(R.id.text_view_Adress);
            textViewAdress=itemView.findViewById(R.id.text_view_Adress);
            recipientName=itemView.findViewById(R.id.text_view_fragil);
            textViewType = itemView.findViewById(R.id.text_view_type);
           // name=itemView.findViewById(R.id.nameofdeliver);
            number = itemView.findViewById(R.id.text_view_number);
            textViewaccept = itemView.findViewById(R.id.text_view_accept);
            textVeiwShiping = itemView.findViewById(R.id.text_view_shiping);
        }
    }
}