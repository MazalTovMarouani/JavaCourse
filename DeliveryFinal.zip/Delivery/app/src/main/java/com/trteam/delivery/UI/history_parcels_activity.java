package com.trteam.delivery.UI;

import android.os.Bundle;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.trteam.delivery.Entitiy.Parcel;
import com.trteam.delivery.Entitiy.ParcelFromFirebase;
import com.trteam.delivery.R;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class history_parcels_activity extends AppCompatActivity {
    // A flexible view for providing a limited window into a large data set.
    private RecyclerView recyclerView;

    // to use layout positions
    private RecyclerView.LayoutManager layoutManager;

    //  for providing views that represent items in a data set.
    private RecyclerView.Adapter mAdapter;

    List<Parcel> parcels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_history_parcels);
        parcels = new ArrayList<Parcel>();
        buildRecyclerView();
    }

    private void buildRecyclerView() {
        // Set the activity content from a layout resource.
        setContentView(R.layout.activity_history_parcels);
        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        // RecyclerView can perform several optimizations if it can know in advance
        // that RecyclerView's size is not affected by the adapter contents.
        // boolean: true if adapter changes cannot affect the size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        // Set the RecyclerView.LayoutManager that this RecyclerView will use.
        recyclerView.setLayoutManager(layoutManager);

        mAdapter = new ParcelListAdapter(history_parcels_activity.this, parcels);
        // Set a new adapter to provide child views on demand.
        recyclerView.setAdapter(mAdapter);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("parcels");

        myRef.addListenerForSingleValueEvent(valueEventListener);
    }

    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            parcels.clear();
            if (dataSnapshot.exists()) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Parcel parcel = snapshot.getValue(Parcel.class);
                    parcels.add(parcel);
                }
                mAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onCancelled(DatabaseError databaseError) {

        }
    };
}