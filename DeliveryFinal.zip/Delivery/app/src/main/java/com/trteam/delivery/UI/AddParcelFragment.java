package com.trteam.delivery.UI;



import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.trteam.delivery.R;

public class AddParcelFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //Inflate a new view hierarchy from the specified xml resource
        return inflater.inflate(R.layout.fragment_add_parcel,container,false);
    }
}