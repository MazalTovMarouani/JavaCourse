package com.trteam.delivery.Entitiy;

public class Enumes {
    public enum ParcelStatus{
        send,
        offer,
        inWay,
        recived,
    }

    public enum ParcelType{
        envelope,
        small,
        large
    }

    public enum ParcelWeight{
        until500gr,
        until1Kg,
        until5Kg,
        until20Kg
    }

}