package com.trteam.delivery.Entitiy;

import androidx.annotation.NonNull;

import com.trteam.delivery.Entitiy.Enumes;

//setting variables for the firebase
public class ParcelFromFirebase {
    public int id;
    public String shippingDate;

//    public String parcelStatus;
//    public String parcelType;
//    public String parcelWeight;

    public Enumes.ParcelStatus parcelStatus;
    public Enumes.ParcelType parcelType;
    public Enumes.ParcelWeight parcelWeight;
    public String number;
    public boolean fragil;
    public String acceptDate;
    public String ShippingDate;
    public Double latitude;
    public Double longitude;

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }
}